const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRouter = require('./routes/auth');
const matchesRouter = require('./routes/matches');
const datesRouter = require('./routes/dates');
const checkinRouter = require('./routes/checkin');
const webhooksRouter = require('./routes/webhooks');
const adminRouter = require('./routes/admin');
const applepayRouter = require('./routes/applepay');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/auth', authRouter);
app.use('/matches', matchesRouter);
app.use('/dates', datesRouter);
app.use('/dates', checkinRouter);
app.use('/webhooks', webhooksRouter);
app.use('/admin', adminRouter);
app.use('/applepay', applepayRouter);
app.use('/.well-known', express.static(require('path').join(__dirname, '../.well-known')));

app.get('/', (req, res) => res.json({ status: 'Monsega-backend draait' }));

module.exports = app;
