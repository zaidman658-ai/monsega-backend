const { createMollieClient } = require('@mollie/api-client');
require('dotenv').config();

const mollieClient = createMollieClient({ apiKey: process.env.MOLLIE_API_KEY });

async function maakBetaling({ bedrag, beschrijving, dateId, userId }) {
  return mollieClient.payments.create({
    amount: { currency: 'EUR', value: bedrag.toFixed(2) },
    description: beschrijving,
    redirectUrl: `${process.env.APP_URL}/dates/${dateId}`,
    webhookUrl: `${process.env.APP_URL}/webhooks/mollie`,
    metadata: { dateId, userId },
  });
}

async function terugbetalen(paymentId, bedrag) {
  return mollieClient.payments_refunds.create({
    paymentId,
    amount: { currency: 'EUR', value: bedrag.toFixed(2) },
  });
}

module.exports = { mollieClient, maakBetaling, terugbetalen };
