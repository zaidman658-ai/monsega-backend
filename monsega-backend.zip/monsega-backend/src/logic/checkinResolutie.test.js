const test = require('node:test');
const assert = require('node:assert');
const { bepaalCheckinUitkomst } = require('./checkinResolutie');

test('wacht op de andere partij als er nog maar 1 melding is', () => {
  const uitkomst = bepaalCheckinUitkomst({ user_id: 'a', kwam_opdagen: true }, null);
  assert.strictEqual(uitkomst.status, 'wacht_op_andere_partij');
});

test('beide kwamen: niemand wordt terugbetaald, bedrag blijft gewoon betaald', () => {
  const uitkomst = bepaalCheckinUitkomst(
    { user_id: 'a', kwam_opdagen: true },
    { user_id: 'b', kwam_opdagen: true }
  );
  assert.strictEqual(uitkomst.status, 'voltooid');
  assert.deepStrictEqual(uitkomst.terugbetalenAan, []);
});

test('eenduidige no-show: alleen wie kwam krijgt zijn geld terug', () => {
  const uitkomst = bepaalCheckinUitkomst(
    { user_id: 'a', kwam_opdagen: false }, // a's partner (b) kwam niet -> a was er zelf wel
    { user_id: 'b', kwam_opdagen: true }
  );
  assert.strictEqual(uitkomst.status, 'no_show_verwerkt');
  assert.deepStrictEqual(uitkomst.terugbetalenAan, ['a']);
});

test('volgorde van de meldingen maakt niets uit', () => {
  const uitkomst = bepaalCheckinUitkomst(
    { user_id: 'b', kwam_opdagen: true },
    { user_id: 'a', kwam_opdagen: false }
  );
  assert.strictEqual(uitkomst.status, 'no_show_verwerkt');
  assert.deepStrictEqual(uitkomst.terugbetalenAan, ['a']);
});

test('tegenstrijdig: allebei zeggen dat de ander wegbleef -> beide terug + review', () => {
  const uitkomst = bepaalCheckinUitkomst(
    { user_id: 'a', kwam_opdagen: false },
    { user_id: 'b', kwam_opdagen: false }
  );
  assert.strictEqual(uitkomst.status, 'conflict_naar_review');
  assert.deepStrictEqual(uitkomst.terugbetalenAan.sort(), ['a', 'b']);
  assert.strictEqual(uitkomst.maakReview, true);
});

test('niemand betaalt dubbel: totale refunds nooit meer dan 2 mensen', () => {
  const gevallen = [
    [true, true], [true, false], [false, true], [false, false],
  ];
  for (const [x, y] of gevallen) {
    const uitkomst = bepaalCheckinUitkomst({ user_id: 'a', kwam_opdagen: x }, { user_id: 'b', kwam_opdagen: y });
    assert.ok(uitkomst.terugbetalenAan.length <= 2);
  }
});
