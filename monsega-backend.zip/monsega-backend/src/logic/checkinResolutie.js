// Pure functie: bepaalt puur op basis van de twee check-in meldingen wat er moet
// gebeuren. Geen database, geen Mollie hier — daardoor makkelijk te testen en
// de plek waar de kern van de no-show-regeling correct moet zijn.

function bepaalCheckinUitkomst(c1, c2) {
  if (!c1 || !c2) {
    return { status: 'wacht_op_andere_partij', terugbetalenAan: [] };
  }

  const beideZeggenWel = c1.kwam_opdagen && c2.kwam_opdagen;
  const beideZeggenNiet = !c1.kwam_opdagen && !c2.kwam_opdagen;

  if (beideZeggenWel) {
    // Alles verliep zoals gepland: het bedrag blijft gewoon betaald
    return { status: 'voltooid', terugbetalenAan: [] };
  }

  if (beideZeggenNiet) {
    // Allebei beweren dat de ander wegbleef: conflict, geen van beide fees blijft staan
    return { status: 'conflict_naar_review', terugbetalenAan: [c1.user_id, c2.user_id], maakReview: true };
  }

  // Eenduidig: kwam_opdagen: false betekent "mijn partner kwam niet" -> ikzelf was er wel
  const wieKwamId = c1.kwam_opdagen === false ? c1.user_id : c2.user_id;
  return { status: 'no_show_verwerkt', terugbetalenAan: [wieKwamId] };
}

module.exports = { bepaalCheckinUitkomst };
