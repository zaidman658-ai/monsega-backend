const express = require('express');
const pool = require('../db/pool');
const { mollieClient } = require('../services/mollie');

const router = express.Router();

// Mollie stuurt hier alleen een payment-id naartoe; de status haal je altijd zelf op (nooit vertrouwen op de payload)
router.post('/mollie', express.urlencoded({ extended: true }), async (req, res) => {
  const paymentId = req.body.id;
  const payment = await mollieClient.payments.get(paymentId);

  if (payment.status === 'paid') {
    await pool.query(`UPDATE betalingen SET status = 'betaald' WHERE mollie_payment_id = $1`, [paymentId]);

    const { rows } = await pool.query(`SELECT date_id FROM betalingen WHERE mollie_payment_id = $1`, [paymentId]);
    const dateId = rows[0]?.date_id;
    if (dateId) {
      const { rows: openRows } = await pool.query(`SELECT COUNT(*) FROM betalingen WHERE date_id = $1 AND status != 'betaald'`, [dateId]);
      if (Number(openRows[0].count) === 0) {
        await pool.query(`UPDATE dates SET status = 'bevestigd' WHERE id = $1`, [dateId]);
      }
    }
  }
  res.sendStatus(200);
});

module.exports = router;
