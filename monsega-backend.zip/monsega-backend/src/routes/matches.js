const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// De curated match van vandaag ophalen
router.get('/vandaag', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT m.id, u.id AS match_user_id, u.naam, u.leeftijd, p.bio, p.prompt_vraag, p.prompt_antwoord, p.interesse_tags
     FROM matches m
     JOIN users u ON u.id = CASE WHEN m.user_a_id = $1 THEN m.user_b_id ELSE m.user_a_id END
     JOIN profielen p ON p.user_id = u.id
     WHERE (m.user_a_id = $1 OR m.user_b_id = $1) AND m.status = 'voorgesteld'
     ORDER BY m.aangemaakt_op DESC LIMIT 1`,
    [req.user.id]
  );
  res.json(rows[0] || null);
});

router.post('/:id/accept', requireAuth, async (req, res) => {
  await pool.query(`UPDATE matches SET status = 'geaccepteerd' WHERE id = $1`, [req.params.id]);
  const { rows } = await pool.query(
    `INSERT INTO dates (match_id, status) VALUES ($1, 'tijden_kiezen') RETURNING id`,
    [req.params.id]
  );
  res.json({ dateId: rows[0].id });
});

router.post('/:id/decline', requireAuth, async (req, res) => {
  await pool.query(`UPDATE matches SET status = 'afgewezen' WHERE id = $1`, [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
