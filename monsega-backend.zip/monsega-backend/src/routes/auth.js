const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');

const router = express.Router();

router.post('/registreer', async (req, res) => {
  const { email, wachtwoord, naam, leeftijd } = req.body;
  if (leeftijd < 18) return res.status(400).json({ error: 'Je moet 18 jaar of ouder zijn' });
  const hash = await bcrypt.hash(wachtwoord, 10);
  try {
    const { rows } = await pool.query(
      `INSERT INTO users (email, wachtwoord_hash, naam, leeftijd) VALUES ($1,$2,$3,$4) RETURNING id`,
      [email, hash, naam, leeftijd]
    );
    const token = jwt.sign({ id: rows[0].id }, process.env.JWT_SECRET, { expiresIn: '30d' });
    res.json({ token });
  } catch (e) {
    res.status(400).json({ error: 'E-mail al in gebruik of ongeldige gegevens' });
  }
});

router.post('/login', async (req, res) => {
  const { email, wachtwoord } = req.body;
  const { rows } = await pool.query(`SELECT * FROM users WHERE email = $1`, [email]);
  if (!rows[0] || !(await bcrypt.compare(wachtwoord, rows[0].wachtwoord_hash))) {
    return res.status(401).json({ error: 'Onjuiste inloggegevens' });
  }
  const token = jwt.sign({ id: rows[0].id }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.json({ token });
});

module.exports = router;
