const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
const { terugbetalen } = require('../services/mollie');
const { bepaalCheckinUitkomst } = require('../logic/checkinResolutie');

const router = express.Router();

// Meld of je datepartner is komen opdagen: { kwam_opdagen: true|false }
// De echte beslislogica staat in src/logic/checkinResolutie.js (en is los getest);
// deze route doet alleen de database- en Mollie-kant van de uitkomst.
router.post('/:id/checkin', requireAuth, async (req, res) => {
  const { kwam_opdagen } = req.body;
  await pool.query(
    `INSERT INTO checkins (date_id, user_id, kwam_opdagen) VALUES ($1,$2,$3)
     ON CONFLICT (date_id, user_id) DO UPDATE SET kwam_opdagen = $3`,
    [req.params.id, req.user.id, kwam_opdagen]
  );

  const { rows: checkins } = await pool.query(`SELECT user_id, kwam_opdagen FROM checkins WHERE date_id = $1`, [req.params.id]);
  const uitkomst = bepaalCheckinUitkomst(checkins[0], checkins[1]);

  if (uitkomst.status === 'wacht_op_andere_partij') {
    return res.json(uitkomst);
  }

  for (const userId of uitkomst.terugbetalenAan) {
    const { rows: betaling } = await pool.query(`SELECT * FROM betalingen WHERE date_id = $1 AND user_id = $2`, [req.params.id, userId]);
    if (betaling[0] && betaling[0].status === 'betaald') {
      await terugbetalen(betaling[0].mollie_payment_id, 10);
      await pool.query(`UPDATE betalingen SET status = 'terugbetaald' WHERE id = $1`, [betaling[0].id]);
    }
  }

  if (uitkomst.maakReview) {
    await pool.query(`INSERT INTO reviews (date_id, reden, status) VALUES ($1, 'tegenstrijdige_meldingen', 'open')`, [req.params.id]);
  }

  const dateStatus = uitkomst.status === 'voltooid' ? 'voltooid' : 'no_show';
  await pool.query(`UPDATE dates SET status = $1 WHERE id = $2`, [dateStatus, req.params.id]);

  res.json(uitkomst);
});

module.exports = router;
