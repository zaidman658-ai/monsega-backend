const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
const { maakBetaling } = require('../services/mollie');

const router = express.Router();

// Voorkeurstijden doorgeven (array van ISO-timestamps)
router.post('/:id/tijden', requireAuth, async (req, res) => {
  const { tijden } = req.body;
  const { rows } = await pool.query(`SELECT match_id FROM dates WHERE id = $1`, [req.params.id]);
  const { rows: matchRows } = await pool.query(`SELECT user_a_id, user_b_id FROM matches WHERE id = $1`, [rows[0].match_id]);
  const kolom = matchRows[0].user_a_id === req.user.id ? 'voorgestelde_tijden_a' : 'voorgestelde_tijden_b';
  await pool.query(`UPDATE dates SET ${kolom} = $1 WHERE id = $2`, [tijden, req.params.id]);
  res.json({ ok: true });
});

// Bevestigen zodra er overlap is tussen beide voorkeuren — triggert de betaling voor beide users
router.post('/:id/bevestig', requireAuth, async (req, res) => {
  const { tijd, locatie } = req.body;
  await pool.query(`UPDATE dates SET bevestigde_tijd = $1, locatie = $2, status = 'bevestigd' WHERE id = $3`, [tijd, locatie, req.params.id]);

  const { rows } = await pool.query(`SELECT match_id FROM dates WHERE id = $1`, [req.params.id]);
  const { rows: matchRows } = await pool.query(`SELECT user_a_id, user_b_id FROM matches WHERE id = $1`, [rows[0].match_id]);
  const userIds = [matchRows[0].user_a_id, matchRows[0].user_b_id];

  const betalingen = [];
  for (const userId of userIds) {
    const payment = await maakBetaling({ bedrag: 10, beschrijving: 'Monsega - date-toezegging', dateId: req.params.id, userId });
    const { rows: bRows } = await pool.query(
      `INSERT INTO betalingen (date_id, user_id, mollie_payment_id, bedrag, status) VALUES ($1,$2,$3,10.00,'open') RETURNING id`,
      [req.params.id, userId, payment.id]
    );
    betalingen.push({ userId, checkoutUrl: payment.getCheckoutUrl(), betalingId: bRows[0].id });
  }
  res.json({ betalingen });
});

module.exports = router;
