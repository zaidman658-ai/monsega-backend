const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
require('dotenv').config();

const router = express.Router();

// Stap 1: de browser vraagt hier een merchant-sessie op (via completeMerchantValidation).
// Dit MOET server-side, Mollie's endpoint accepteert geen browseraanvragen.
router.post('/session', async (req, res) => {
  const { validationUrl, domain } = req.body;
  try {
    const mollieRes = await fetch('https://api.mollie.com/v2/wallets/applepay/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.MOLLIE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ domain, validationUrl }),
    });
    const session = await mollieRes.json();
    res.json(session);
  } catch (e) {
    res.status(500).json({ error: 'Kon geen Apple Pay-sessie starten bij Mollie' });
  }
});

// Stap 2: zodra de shopper met Face ID/Touch ID heeft bevestigd, komt hier het betaaltoken binnen
router.post('/:dateId/betaal', requireAuth, async (req, res) => {
  const { applePayPaymentToken } = req.body; // de event.payment.token, als JSON-string
  try {
    const mollieRes = await fetch('https://api.mollie.com/v2/payments', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.MOLLIE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: { currency: 'EUR', value: '10.00' },
        description: 'Monsega - date-toezegging',
        method: 'creditcard',
        applePayPaymentToken,
        redirectUrl: `${process.env.APP_URL}/dates/${req.params.dateId}`,
        webhookUrl: `${process.env.APP_URL}/webhooks/mollie`,
        metadata: { dateId: req.params.dateId, userId: req.user.id },
      }),
    });
    const payment = await mollieRes.json();
    await pool.query(
      `INSERT INTO betalingen (date_id, user_id, mollie_payment_id, bedrag, status) VALUES ($1,$2,$3,10.00,'open')`,
      [req.params.dateId, req.user.id, payment.id]
    );
    res.json({ paymentId: payment.id, status: payment.status });
  } catch (e) {
    res.status(500).json({ error: 'Apple Pay-betaling mislukt' });
  }
});

module.exports = router;
