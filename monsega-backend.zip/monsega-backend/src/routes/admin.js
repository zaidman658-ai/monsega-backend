const express = require('express');
const pool = require('../db/pool');
const { requireAuth } = require('../middleware/auth');
// TODO: voeg een requireAdmin-check toe (bv. een rol-veld op users, of een apart admin-account/tabel)

const router = express.Router();

router.get('/stats', requireAuth, async (req, res) => {
  const { rows: [gebruikers] } = await pool.query(`SELECT COUNT(*) FROM users`);
  const { rows: [datesWeek] } = await pool.query(`SELECT COUNT(*) FROM dates WHERE bevestigde_tijd > now() - interval '7 days'`);
  const { rows: [omzet] } = await pool.query(`SELECT COALESCE(SUM(bedrag),0) AS totaal FROM betalingen WHERE status = 'betaald' AND aangemaakt_op > now() - interval '7 days'`);
  const { rows: [reviews] } = await pool.query(`SELECT COUNT(*) FROM reviews WHERE status = 'open'`);
  res.json({
    actieveGebruikers: Number(gebruikers.count),
    datesDezeWeek: Number(datesWeek.count),
    omzetDezeWeek: Number(omzet.totaal),
    openReviews: Number(reviews.count),
  });
});

router.get('/matches', requireAuth, async (req, res) => {
  const { rows } = await pool.query(`
    SELECT d.id, ua.naam AS naam_a, ub.naam AS naam_b, d.bevestigde_tijd, d.locatie, d.status
    FROM dates d
    JOIN matches m ON m.id = d.match_id
    JOIN users ua ON ua.id = m.user_a_id
    JOIN users ub ON ub.id = m.user_b_id
    ORDER BY d.bevestigde_tijd DESC NULLS LAST
  `);
  res.json(rows);
});

router.get('/reviews', requireAuth, async (req, res) => {
  const { rows } = await pool.query(`SELECT * FROM reviews WHERE status = 'open' ORDER BY aangemaakt_op DESC`);
  res.json(rows);
});

router.post('/reviews/:id/resolve', requireAuth, async (req, res) => {
  const { actie } = req.body;
  await pool.query(`UPDATE reviews SET status = 'afgehandeld', actie = $1 WHERE id = $2`, [actie, req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
