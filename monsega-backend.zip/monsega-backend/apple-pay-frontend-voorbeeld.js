// Voorbeeldcode voor de "Betaal met Apple Pay"-knop in de app zelf.
// LET OP: dit werkt alleen op een echt, HTTPS-domein waar het
// domeinverificatiebestand publiek bereikbaar is, en alleen op een Apple-toestel.
// Kan dus NIET getest worden in deze Claude-mockup - pas integreren zodra
// je backend en een echt domein live staan.

async function betaalMetApplePay(dateId, authToken) {
  const request = {
    countryCode: 'NL',
    currencyCode: 'EUR',
    supportedNetworks: ['visa', 'masterCard', 'amex'],
    merchantCapabilities: ['supports3DS'],
    total: { label: 'Monsega', amount: '10.00' },
  };

  const session = new ApplePaySession(3, request);

  session.onvalidatemerchant = async (event) => {
    const res = await fetch('/applepay/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ validationUrl: event.validationURL, domain: window.location.hostname }),
    });
    session.completeMerchantValidation(await res.json());
  };

  session.onpaymentauthorized = async (event) => {
    const applePayPaymentToken = JSON.stringify(event.payment.token);
    const res = await fetch(`/applepay/${dateId}/betaal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${authToken}` },
      body: JSON.stringify({ applePayPaymentToken }),
    });
    const result = await res.json();
    session.completePayment(
      result.paymentId ? ApplePaySession.STATUS_SUCCESS : ApplePaySession.STATUS_FAILURE
    );
  };

  session.begin();
}

// Toon de knop alleen als het écht kan:
// if (window.ApplePaySession && ApplePaySession.canMakePayments()) { toonKnop(); }
