# Monsega — backend

Node.js/Express + PostgreSQL, zelfde stack als je beveiligingsplatform.

## Starten
1. `npm install`
2. Kopieer `.env.example` naar `.env` en vul in (database-URL, JWT-secret, Mollie-testkey)
3. Database opzetten: `npm run migrate` (of voer `src/db/schema.sql` handmatig uit met een Postgres-client)
4. `npm run dev`

## Structuur
- `src/db/schema.sql` — alle tabellen
- `src/routes/` — matches, dates, checkin, webhooks, admin, auth
- `src/services/mollie.js` — betaling aanmaken + terugbetalen

## iDEAL & Apple Pay activeren
1. Zet in je Mollie-dashboard onder Settings > Payment methods **iDEAL** en **creditcards** aan (Apple Pay vereist dat creditcards al actief zijn)
2. Zet daarna **Apple Pay** aan en doorloop Mollie's domeinverificatie voor je live-domein
3. Vervang `.well-known/apple-developer-merchantid-domain-association` door het echte bestand dat je daar downloadt
4. De gewone betaalpagina (`getCheckoutUrl()`) toont iDEAL automatisch. Wil je een échte Apple Pay-knop in je eigen UI, gebruik dan `apple-pay-frontend-voorbeeld.js` samen met de nieuwe `src/routes/applepay.js`

## Let op vóór productie
- Voeg een `requireAdmin`-check toe aan de admin-routes (nu alleen `requireAuth`)
- De 24-uurs-time-out bij een eenzijdige no-show-melding is hier nog niet geautomatiseerd — dat vraagt een cron-job/scheduled task
- Laat de algemene voorwaarden en het herroepingsrecht juridisch nakijken voor je live gaat
- Zet `MOLLIE_API_KEY` pas op een live-key als je een echte Mollie-bedrijfsaccount hebt
